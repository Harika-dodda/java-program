package com.simpilearn.bddtest.Phase2_Selenium_StarHealth_App;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
